# TriviaMania

## TriviaMania allows you to play trivia games.
#### It is built using node, express, javascript, css3, mongoDb, etc
