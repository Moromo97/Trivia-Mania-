module.exports = {
    mongoURI: 'mongodb+srv://andy1:test@todo.87clq.mongodb.net/test?retryWrites=true&w=majority'
}